package net.sqlcipher;

public interface CursorWindowAllocation {
  long getAllocationSize();
}
