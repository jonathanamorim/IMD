/**
 * Contains the SQLCipher database managements classes that an application would use to manage its own private database.
 */
package net.sqlcipher.database;
