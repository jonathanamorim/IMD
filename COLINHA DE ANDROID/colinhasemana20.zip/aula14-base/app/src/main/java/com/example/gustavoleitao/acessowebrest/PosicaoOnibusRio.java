package com.example.gustavoleitao.acessowebrest;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by gustavoleitao on 07/08/17.
 */

public class PosicaoOnibusRio implements Serializable {

    private Date dataHora;
    private String ordem;
    private String linha;
    private Double latitude;
    private Double longitude;
    private Double velocidade;

    public Date getDataHora() {
        return dataHora;
    }

    public void setDataHora(Date dataHora) {
        this.dataHora = dataHora;
    }

    public String getOrdem() {
        return ordem;
    }

    public void setOrdem(String ordem) {
        this.ordem = ordem;
    }

    public String getLinha() {
        return linha;
    }

    public void setLinha(String linha) {
        this.linha = linha;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(Double velocidade) {
        this.velocidade = velocidade;
    }

    @Override
    public String toString() {
        return "PosicaoOnibusRio{" +
                "dataHora=" + dataHora +
                ", ordem='" + ordem + '\'' +
                ", linha='" + linha + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", velocidade=" + velocidade +
                '}';
    }
}
