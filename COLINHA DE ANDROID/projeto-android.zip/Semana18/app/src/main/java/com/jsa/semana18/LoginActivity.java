package com.jsa.semana18;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    EditText txtEmail_Login;
    EditText txtPassword_Login;
    Button btnEntrar;
    AppCompatButton btnCreateRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        txtEmail_Login = (EditText)findViewById(R.id.txtEmail_Login);
        txtPassword_Login = (EditText)findViewById(R.id.txtPassword_Login);
        btnEntrar = (Button)findViewById(R.id.btnEntrar);
        btnEntrar.setOnClickListener(this);
        btnCreateRegister = (AppCompatButton)findViewById(R.id.btnCreateRegister);
        btnCreateRegister.setOnClickListener(this);
    }

    private void verifyFromDB(){

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnEntrar:
                Intent loginRedirect = new Intent(this, MainActivity.class);
                startActivity(loginRedirect);
                break;
            case R.id.btnRegister:
                Intent registerRedirect = new Intent(this, RegisterActivity.class);
                startActivity(registerRedirect);
        }
    }
}
