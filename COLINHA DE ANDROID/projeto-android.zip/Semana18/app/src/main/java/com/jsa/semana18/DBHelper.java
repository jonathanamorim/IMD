package com.jsa.semana18;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    private final static String DB_NAME = "ThunderDB";
    private final static String TB_USER = "TBUSER";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            String CREATE_TABLE = "CREATE TABLE TBUSER (_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "Name VARCHAR(100) NOT NULL," +
                    " Sobrenome VARCHAR(100) NOT NULL," +
                    " Email VARCHAR(100) NOT NULL," +
                    " Password VARCHAR(20) NOT NULL)";
            Log.v("CRIAR TABELA : ",CREATE_TABLE);
            db.execSQL(CREATE_TABLE);
        }catch (Exception e){
            Log.e("DBHelper",e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newerVersion) {
        try{
            db.execSQL("DROP TABLE IF EXISTS TBUSER");
            onCreate(db);
        }catch (Exception e){
            Log.e("DBHelper",e.getMessage());
        }
    }
}
