package com.jsa.semana18;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    EditText txtName;
    EditText txtSobre;
    EditText txtEmail;
    EditText txtPassword;
    Button btnRegister;
    Button btnList;
    DBHelper dbHelper;
    SQLiteDatabase ThunderDB;
    TextView txtView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        txtName = (EditText)findViewById(R.id.txtName);
        txtSobre = (EditText)findViewById(R.id.txtSobre);
        txtEmail = (EditText)findViewById(R.id.txtEmail);
        txtPassword = (EditText)findViewById(R.id.txtPassword);
        btnRegister = (Button)findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);
        btnList = (Button)findViewById(R.id.btnList);
        btnList.setOnClickListener(this);
        dbHelper = new DBHelper(this);
        txtView = (TextView)findViewById(R.id.txtView);
    }

    private void insertUser(){
        EditText edtName = (EditText)findViewById(R.id.txtName);
        EditText edtSobre = (EditText)findViewById(R.id.txtSobre);
        EditText edtEmail = (EditText)findViewById(R.id.txtEmail);
        EditText edtPassword = (EditText)findViewById(R.id.txtPassword);
        String name = edtName.getText().toString();
        String sobrenome = edtSobre.getText().toString();
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();
        ContentValues cv = new ContentValues();
        cv.put("Name",name);
        cv.put("Sobrenome",sobrenome);
        cv.put("Email",email);
        cv.put("Password",password);
        try{
            ThunderDB = dbHelper.getWritableDatabase();
            ThunderDB.insert("TBUSER",null,cv);
            Log.v("INSIRA MENSAGEM","SUCESSO");
            txtName.setText("");
            txtSobre.setText("");
            txtEmail.setText("");
            txtPassword.setText("");
            Toast.makeText(this,"Bem vindo "+name,Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Log.e("INSERIR NOME",e.getMessage());
        }
        ThunderDB.close();
    }

    private void displayData(){
        try{
            ThunderDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name","Sobrenome","Email","Password"};
            Cursor cursor = ThunderDB.query("TBUSER",columns,null,null,null,null,null);
            while (cursor.moveToNext()){
                String name = cursor.getString(cursor.getColumnIndex("Name"));
                String sobrenome = cursor.getString(cursor.getColumnIndex("Sobrenome"));
                String email = cursor.getString(cursor.getColumnIndex("Email"));
                String password = cursor.getString(cursor.getColumnIndex("Password"));
                txtView.setText(
                        "Nome: "+name+"\n"+
                        "Sobrenome: "+sobrenome+"\n"+
                        "Email: "+email+"\n"+
                        "Senha: "+password
                );
            }
        }catch (Exception e){
            Log.e("REGISTRO ACTIVITY : "," RECORDS");
        }
        ThunderDB.close();
    }




    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnRegister:
                insertUser();
                    break;
            case R.id.btnList:
                displayData();
                    break;
        }
    }
}
