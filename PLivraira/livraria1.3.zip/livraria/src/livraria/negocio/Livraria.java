package livraria.negocio;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import livraria.bd.RepositorioLivrosJDBC;
import livraria.negocio.excecoes.CompraException;
import livraria.negocio.excecoes.LivroNaoEncontradoException;

public class Livraria {
	//AQUI J� FAZ UMA CONEXAO COM A CLASS REPOSITORIO PARA ARMAZENAR OS LIVROS NO BANCO DE DADOS
    private RepositorioLivrosJDBC estoqueLivros;
    
    public Livraria() {
        estoqueLivros = new RepositorioLivrosJDBC();
    }
       
    //M�TODO QUE CHAMA O OUTRO M�TODO PARA FAZER A BUSCA DOS LIVROS NO BANCO 'C�DIGO NOVO'
    public List<Livro> buscarLivros(String palavra) {
        List<Livro> livros;
        livros = estoqueLivros.buscarLivros(palavra);
        return livros;
    }
    
    public List<Livro> getLivros() {
        List<Livro> livros;      
        livros = estoqueLivros.getLivros();        
        return livros;
    }

    public Livro getLivro(String idLivro) throws LivroNaoEncontradoException {
        
    	Livro livro;        
        livro = estoqueLivros.getLivro(idLivro);         
        return livro; 
    	
    }
    
    public void comprarLivros(CarrinhoCompras carrinho) throws CompraException {
        Collection<ItemCompra> items = carrinho.getItens();
        Iterator<ItemCompra> i = items.iterator();

        while (i.hasNext()) {
            ItemCompra item = (ItemCompra) i.next();
            Livro livro = (Livro) item.getItem();
            String id = livro.getIdLivro();
            int quantity = item.getQuantidade();
            comprarLivro(id, quantity);
        }
    }

    public void comprarLivro(String idLivro, int qtdComprada) throws CompraException {
    	Livro livroSelecionado;
    	try { 
    		livroSelecionado = getLivro(idLivro);

    		int qtdEstoque = livroSelecionado.getQuantidade(); 

    		if ((qtdEstoque - qtdComprada) >= 0) { 
     			int novaQtd = qtdEstoque - qtdComprada; 
     			livroSelecionado.setQuantidade(novaQtd);
    		} else { 
        			throw new CompraException("Livro " + idLivro 
                    + " sem estoque suficiente."); 
    		}
    		estoqueLivros.atualizaLivro(idLivro, livroSelecionado);
    	} catch (LivroNaoEncontradoException e) { 
    	
    		throw new CompraException(e.getMessage()); 
    	}
    }

    public void fechar() {
        // liberaria conex�es de banco de dados, se usasse
    }
}