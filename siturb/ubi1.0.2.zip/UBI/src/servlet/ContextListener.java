package servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import model.*;

public class ContextListener implements ServletContextListener{
	public static final String SISTEMA_UBI = "sistemaUbi";

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		ServletContext context = arg0.getServletContext();
		try {
			Onibus o = new Onibus();
			context.setAttribute(SISTEMA_UBI, o);
		}catch(Exception e) {
			e.getMessage();
		}
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		ServletContext context = arg0.getServletContext();
		Onibus o = (Onibus)context.getAttribute(SISTEMA_UBI);
        if (o != null) {
            
        }
        context.removeAttribute(SISTEMA_UBI);

	}
}
