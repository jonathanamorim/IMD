package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.*;

public class RepositorioJDBC {
	private Connection conexaoBD;
	public RepositorioJDBC() {
		this.conexaoBD = GerenciadorConexao.getConexao();
	}
	
	public Cobrador getCobrador (String nome){
		Cobrador cobrador = new Cobrador();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM cobrador WHERE nome=?");
			st.setString(1, nome);
			ResultSet result = st.executeQuery();
			
			if (result.first()) {
				cobrador.setNome(result.getString("nome"));
				cobrador.setCpf(result.getString("cpf"));
				cobrador.setMatricula(result.getString("matricula"));
				cobrador.setEndereco(result.getString("endereco"));
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return cobrador;
	}

	public List<Cobrador> Cobrador() {	  
		List<Cobrador> cobradores = new ArrayList<Cobrador>();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM cobrador");
			ResultSet result = st.executeQuery();
			
			while (result.next()) {
				Cobrador cobrador = new Cobrador();
				cobrador.setNome(result.getString("nome"));
				cobrador.setCpf(result.getString("cpf"));
				cobrador.setMatricula(result.getString("matricula"));
				cobrador.setEndereco(result.getString("endereco"));				
				cobradores.add(cobrador);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return cobradores;
	}
	
	public List<Cobrador> buscarCobrador(String r) {
	    List<Cobrador> cobradores = new ArrayList<Cobrador>();
	        try {
	            PreparedStatement st;
	            st = this.conexaoBD.prepareStatement("SELECT * FROM cobrador WHERE nome LIKE ?");
	            st.setString(1, "%" + r + "%");
	            ResultSet result = st.executeQuery();
	        
	            while (result.next()) {
	            	Cobrador cobrador = new Cobrador();
					cobrador.setNome(result.getString("nome"));
					cobrador.setCpf(result.getString("cpf"));
					cobrador.setMatricula(result.getString("matricula"));
					cobrador.setEndereco(result.getString("endereco"));				
					cobradores.add(cobrador);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    return cobradores;
	}
	
	public Motorista getMotorista (String nome){
		Motorista motorista = new Motorista();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM motorista WHERE nome=?");
			st.setString(1, nome);
			ResultSet result = st.executeQuery();

			if (result.first()) {	
				motorista.setNome(result.getString("nome"));
				motorista.setCpf(result.getString("cpf"));
				motorista.setMatricula(result.getString("matricula"));
				motorista.setEndereco(result.getString("endereco"));
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return motorista;
	}
	
	public List<Motorista> Motorista() {	  
		List<Motorista> motoristas = new ArrayList<Motorista>();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM motorista");
			ResultSet result = st.executeQuery();
			
			while (result.next()) {
				Motorista motorista = new Motorista();
				motorista.setNome(result.getString("nome"));
				motorista.setCpf(result.getString("cpf"));
				motorista.setMatricula(result.getString("matricula"));
				motorista.setEndereco(result.getString("endereco"));				
				motoristas.add(motorista);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return motoristas;
	}
	
	public List<Motorista> buscarMotorista(String r) {
	    List<Motorista> motoristas = new ArrayList<Motorista>();
	        try {
	            PreparedStatement st;
	            st = this.conexaoBD.prepareStatement("SELECT * FROM motorista WHERE nome LIKE ?");
	            st.setString(1, "%" + r + "%");
	            ResultSet result = st.executeQuery();
	        
	            while (result.next()) {
	            	Motorista motorista = new Motorista();
					motorista.setNome(result.getString("nome"));
					motorista.setCpf(result.getString("cpf"));
					motorista.setMatricula(result.getString("matricula"));
					motorista.setEndereco(result.getString("endereco"));				
					motoristas.add(motorista);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    return motoristas;
	}

	public Empresa getEmpresa (String razao_social){
		Empresa empresa = new Empresa();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM empresa WHERE razao_social=?");
			st.setString(1, razao_social);
			ResultSet result = st.executeQuery();

			if (result.first()) {	
				empresa.setRazaoSocial(result.getString("razao_social"));
				empresa.setCnpj(result.getString("cnpj"));
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return empresa;
	}
	
	public List<Empresa> Empresa() {	  
		List<Empresa> empresas = new ArrayList<Empresa>();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM empresa");
			ResultSet result = st.executeQuery();
			
			while (result.next()) {
				Empresa empresa = new Empresa();
				empresa.setRazaoSocial(result.getString("razao_social"));
				empresa.setCnpj(result.getString("cnpj"));				
				empresas.add(empresa);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return empresas;
	}	
	
	public List<Empresa> buscarEmpresa(String r) {
	    List<Empresa> empresas = new ArrayList<Empresa>();
	        try {
	            PreparedStatement st;
	            st = this.conexaoBD.prepareStatement("SELECT * FROM empresa WHERE razao_social LIKE ?");
	            st.setString(1, "%" + r + "%");
	            ResultSet result = st.executeQuery();
	        
	            while (result.next()) {
	            	Empresa empresa = new Empresa();
					empresa.setRazaoSocial(result.getString("razao_social"));
					empresa.setCnpj(result.getString("cnpj"));				
					empresas.add(empresa);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    return empresas;
	}

	public Onibus getOnibus(String marca){
		Onibus onibus = new Onibus();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM onibus WHERE marca=?");
			st.setString(1, marca);
			ResultSet result = st.executeQuery();

			if (result.first()) {	
				onibus.setMarca(result.getString("marca"));
				onibus.setModelo(result.getString("modelo"));
				onibus.setAno(result.getInt("ano"));
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return onibus;
	}
	
	public List<Onibus> Onibus() {	  
		List<Onibus> onibuss = new ArrayList<Onibus>();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM onibus");
			ResultSet result = st.executeQuery();
			
			while (result.next()) {
				Onibus onibus = new Onibus();
				onibus.setMarca(result.getString("marca"));
				onibus.setModelo(result.getString("modelo"));
				onibus.setAno(result.getInt("ano"));			
				onibuss.add(onibus);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return onibuss;
	}	
	
	public List<Onibus> buscarOnibus(String r) {
	    List<Onibus> onibuss = new ArrayList<Onibus>();
	        try {
	            PreparedStatement st;
	            st = this.conexaoBD.prepareStatement("SELECT * FROM onibus WHERE marca LIKE ?");
	            st.setString(1, "%" + r + "%");
	            ResultSet result = st.executeQuery();
	        
	            while (result.next()) {
	            	Onibus onibus = new Onibus();
					onibus.setMarca(result.getString("marca"));
					onibus.setModelo(result.getString("modelo"));
					onibus.setAno(result.getInt("ano"));			
					onibuss.add(onibus);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    return onibuss;
	}

	public Rota getRota(String ident){
		Rota rota  = new Rota();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM linha WHERE ident=?");
			st.setString(1, ident);
			ResultSet result = st.executeQuery();
			
			if (result.first()) {	
				rota.setIdent(result.getString("ident"));
				rota.setOrigem(result.getString("origem"));
				rota.setDestino(result.getString("destino"));
				rota.setHoraChegada(result.getString("hora_chegada"));
				rota.setHoraSaida(result.getString("hora_saida"));
			}
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return rota;
	}
	
	public List<Rota> Rota() {	  
		List<Rota> rotas = new ArrayList<Rota>();
		try {
			PreparedStatement st;
			st = this.conexaoBD.prepareStatement("SELECT * FROM linha");
			ResultSet result = st.executeQuery();
			
			while (result.next()) {
				Rota rota  = new Rota();
				rota.setIdent(result.getString("ident"));
				rota.setOrigem(result.getString("origem"));
				rota.setDestino(result.getString("destino"));
				rota.setHoraChegada(result.getString("hora_chegada"));
				rota.setHoraSaida(result.getString("hora_saida"));
				rotas.add(rota);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return rotas;
	}
	
	public List<Rota> buscarRotas(String r) {
	    List<Rota> rotas = new ArrayList<Rota>();
	        try {
	            PreparedStatement st;
	            st = this.conexaoBD.prepareStatement("SELECT * FROM linha WHERE ident LIKE ?");
	            st.setString(1, "%" + r + "%");
	            ResultSet result = st.executeQuery();
	        
	            while (result.next()) {
	            	Rota rota  = new Rota();
					rota.setIdent(result.getString("ident"));
					rota.setOrigem(result.getString("origem"));
					rota.setDestino(result.getString("destino"));
					rota.setHoraChegada(result.getString("hora_chegada"));
					rota.setHoraSaida(result.getString("hora_saida"));
					rotas.add(rota);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    return rotas;
	}
}
