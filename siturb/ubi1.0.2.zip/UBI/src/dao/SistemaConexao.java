package dao;

import java.util.List;
import model.*;

public class SistemaConexao {
	private RepositorioJDBC sistema;
	public SistemaConexao() {
		sistema = new RepositorioJDBC();
	}
	
	public List<Onibus> getOnibus(){
		List<Onibus> onibus;
		onibus = sistema.Onibus();
		return onibus;
	}
	
	public List<Onibus> buscarOnibus(String r){
		List<Onibus> onibuss;
		onibuss = sistema.buscarOnibus(r);
		return onibuss;
	}
	
	public List<Motorista> getMotorista(){
		List<Motorista> motoristas;
		motoristas = sistema.Motorista();
		return motoristas;
	}
	
	public List<Motorista> buscarMotorista(String nome){
		List<Motorista> motoristas;
		motoristas = sistema.buscarMotorista(nome);
		return motoristas;
	}
	
	public List<Cobrador> getCobrador(){
		List<Cobrador> cobradores;
		cobradores = sistema.Cobrador();
		return cobradores;
	}
	
	public List<Cobrador> buscarCobrador(String nome){
		List<Cobrador> cobradores;
		cobradores = sistema.buscarCobrador(nome);
		return cobradores;
	}
	
	public List<Empresa> getEmpresa(){
		List<Empresa> empresas;
		empresas = sistema.Empresa();
		return empresas;
	}
	
	public List<Empresa> buscarEmpresa(String cnpj){
		List<Empresa> empresas;
		empresas = sistema.buscarEmpresa(cnpj);
		return empresas;
	}
	
	public List<Rota> getRota(){
		List<Rota> rotas;
		rotas = sistema.Rota();
		return rotas;
	}
	
	public List<Rota> buscarRota(String ident){
		List<Rota> rotas;
		rotas = sistema.buscarRotas(ident);
		return rotas;
	}
}
