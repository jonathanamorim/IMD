package controllers;

import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import model.*;

@ManagedBean
@SessionScoped
public class CadastrarRotaMBean {	
	private Rota rota;
	private List<Rota> rotas;
	
	public CadastrarRotaMBean() {
		rota = new Rota();
		rotas = new ArrayList<Rota>();
		}
	 
	public String entrarCadastro(){
		return "/form-rota.jsf";
	}
	 
	public String voltar(){
		return "/index.jsf";
	}
	 
	public String cadastrar() {
		rotas.add(rota);
		rota = new Rota();
		FacesMessage msg = new FacesMessage("Rota cadastrada");
		msg.setSeverity(FacesMessage.SEVERITY_INFO);
		FacesContext.getCurrentInstance().addMessage("", msg);
		return "/form-rota.jsf";
	}
	 
	public Rota getRota() {
		return rota;
	}
	 
	public void setRota(Rota rota) {
		this.rota = rota;
	}
	 
	public List<Rota> getRotas() {
		return rotas;
	}
	 
	public void setRotas(List<Rota> rotas) {
		this.rotas = rotas;
	}
	
}
