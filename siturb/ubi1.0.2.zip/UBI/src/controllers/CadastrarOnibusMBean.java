package controllers;

import model.*;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped
public class CadastrarOnibusMBean {
	private Onibus onibus;
	private List<Onibus> listagem;
	
	public CadastrarOnibusMBean(){
		iniciarValores();
		listagem = new ArrayList<Onibus>();
	}
	
	private void iniciarValores() {
		onibus = new Onibus();
		onibus.setCobrador(new Cobrador());
		onibus.setMotorista(new Motorista());
		onibus.setEmpresa(new Empresa());
		onibus.setRota(new Rota());
		}
	
	public String entrarCadastro(){
		return "/form-onibus.jsf";
	}
	
	public String listar(){
		return "/list-onibus.jsf";
	}
	
	public String voltar(){
		return "/index.jsf";
	}
	
	public String cadastrar(){
		listagem.add(onibus);
		iniciarValores();
		FacesMessage msg = new FacesMessage("Onibus cadastrado com sucesso!");
		msg.setSeverity(FacesMessage.SEVERITY_INFO);
		FacesContext.getCurrentInstance().addMessage("", msg);
		return "/form-onibus.jsf";
	}
	
	public Onibus getOnibus() {
		return onibus;
	}
	 
	public void setOnibus(Onibus onibus) {
		this.onibus = onibus;
	}
	public List<Onibus> getListagem() {
		return listagem;
	}
	 
	public void setListagem(List<Onibus> listagem) {
		this.listagem = listagem;
	}
}