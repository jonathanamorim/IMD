package model;

public class Motorista extends Cobrador {
	 
	private String registroCnh;
	 
	private String categoriaCnh;
	
	private String cadastrarCnh;
	 
	public String getRegistroCnh() {
		return registroCnh;
	}
	 
	public void setRegistroCnh(String registroCnh) {
		this.registroCnh = registroCnh;
	}
	 
	public String getCategoriaCnh() {
		return categoriaCnh;
	}
	 
	public void setCategoriaCnh(String categoriaCnh) {
		this.categoriaCnh = categoriaCnh;
	}

	public String getCadastrarCnh() {
		return cadastrarCnh;
	}

	public void setCadastrarCnh(String cadastrarCnh) {
		this.cadastrarCnh = cadastrarCnh;
	}
 
}
